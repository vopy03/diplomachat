export { default as de } from './lang-de';
export { default as en } from './lang-en';
export { default as fi } from './lang-fi';
export { default as fr } from './lang-fr';
export { default as nl } from './lang-nl';
export { default as no } from './lang-no';
export { default as sv } from './lang-sv';

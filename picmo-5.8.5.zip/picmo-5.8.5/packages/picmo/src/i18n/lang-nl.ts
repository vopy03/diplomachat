export default {
    'categories.activities': 'Activiteiten',
    'categories.animals-nature': 'Dieren & Natuur',
    'categories.custom': 'Aangepast',
    'categories.flags': 'Vlaggen',
    'categories.food-drink': 'Eten & Drinken',
    'categories.objects': 'Voorwerpen',
    'categories.people-body': 'Mens & Lichaam',
    'categories.recents': 'Laatst gebruikt',
    'categories.smileys-emotion': 'Smileys en emoties',
    'categories.symbols': 'Symbolen',
    'categories.travel-places': 'Reizen & Plaatsen',
    'error.load': 'Kan emoji\'s niet laden',
    'recents.clear': 'Wis recente emoji\'s',
    'recents.none': 'Geen emoji geselecteerd.',
    'retry': 'Probeer het nog eens',
    'search.clear': 'Zoekopdracht wissen',
    'search.error': 'Zoeken mislukt',
    'search.notFound': 'Geen emoji gevonden',
    'search': 'Zoek emoji...'
  };
  
import createConfig from '../../vite.common';

export default createConfig(__dirname, 'picmoTwemoji');

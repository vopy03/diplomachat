# `InMemoryStoreFactory`

Creates an in-memory store.

```javascript
import { InMemoryStoreFactory } from 'picmo';
```

<pre>
InMemoryStoreFactory(locale: <a href="https://emojibase.dev/api/emojibase#Locale">Locale</a>): InMemoryStore
</pre>
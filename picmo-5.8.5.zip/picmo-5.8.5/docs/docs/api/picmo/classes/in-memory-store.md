# `InMemoryStore`

A simple in-memory data store. All emoji and category data are held in memory, so this has a performance cost. However, this may be necessary in some environments (such as iframes) where IndexedDB is not available.

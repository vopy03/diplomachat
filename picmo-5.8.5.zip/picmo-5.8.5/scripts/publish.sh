#!/bin/zsh

npm publish --workspace packages --access public
